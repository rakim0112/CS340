from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """CRUD operations for the Austin Animal Center collection in MongoDB."""

    def __init__(self, username, password, host="localhost", port=27017,
                 db="aac", collection="animals"):
        """Initialize MongoDB connection."""
        try:
            self.client = MongoClient(
                host=host,
                port=port,
                username=username,
                password=password,
                authSource=db
            )
            self.database = self.client[db]
            self.collection = self.database[collection]
        except PyMongoError as e:
            print(f"Connection error: {e}")
            raise

    def create(self, data):
        """Insert a document into the collection."""
        if not data:
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"Create error: {e}")
            return False

    def read(self, query):
        """Read documents from the collection."""
        if query is None:
            return []

        try:
            return list(self.collection.find(query))
        except PyMongoError as e:
            print(f"Read error: {e}")
            return []

    def update(self, query, new_values):
        """Update matching documents in the collection."""
        if not query or not new_values:
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"Update error: {e}")
            return 0

    def delete(self, query):
        """Delete matching documents from the collection."""
        if not query:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete error: {e}")
            return 0